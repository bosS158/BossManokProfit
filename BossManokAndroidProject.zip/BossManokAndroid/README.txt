BOSS MANOK PROFIT — ANDROID APP PROJECT

This project wraps the existing Boss Manok Profit Control app in an Android WebView.
The app works offline and stores data locally on the phone/browser app storage.

IMPORTANT
- This ZIP is Android source code, not a compiled APK.
- Building an APK requires Android Studio (or Android SDK + Gradle build tools).
- Data stays on this phone. It does not automatically sync to staff phones or cloud.
- Back up your records using the app's JSON export feature and keep the backup somewhere safe.
- Confirm your actual rice-cup weight/cost and daily ingredient usage before relying on profit estimates.

BUILD AN APK WITH ANDROID STUDIO
1. Extract this ZIP on a computer.
2. Install Android Studio from the official Android developer website.
3. Open Android Studio > Open, then select the extracted BossManokAndroid folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, choose Locate. The debug APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

APP ID: com.bossmanok.profit
APP NAME: Boss Manok Profit
MINIMUM ANDROID: Android 6.0 (API 23)

ACCOUNTING NOTE
The app estimates operating profit from sales and entered costs. Profit estimates are only as accurate as your entries.
Do not count the same purchase as both consumed-cost and expense twice. Cash flow and profit are different:
unsold stock is inventory, not automatically a cost of goods sold.
